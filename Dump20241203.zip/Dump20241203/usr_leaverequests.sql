-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: usr
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leaverequests`
--

DROP TABLE IF EXISTS `leaverequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaverequests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` varchar(255) NOT NULL,
  `sin_number` varchar(255) NOT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `staff_name` varchar(255) DEFAULT NULL,
  `hod_name` varchar(255) DEFAULT NULL,
  `department` varchar(255) NOT NULL,
  `year` int DEFAULT NULL,
  `request_type` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `pdf_path` longblob,
  `class_advisor_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `hod_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `principal_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `placement_officer_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaverequests`
--

LOCK TABLES `leaverequests` WRITE;
/*!40000 ALTER TABLE `leaverequests` DISABLE KEYS */;
INSERT INTO `leaverequests` VALUES (1,'od-001','e21cs024','kavi',NULL,NULL,'cse',4,'od','intern tcs','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'approved','pending','pending','pending','2024-11-16 15:06:54','2024-11-16 15:06:54'),(2,'od-002','e21cs024','kavi',NULL,NULL,'cse',4,'od','intern tcs','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'pending','pending','pending','pending','2024-11-16 16:47:11','2024-11-16 16:47:11'),(3,'od-003','e21cs015','joe',NULL,NULL,'agri',4,'od','tour pooorom','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'pending','pending','pending','pending','2024-11-16 16:48:05','2024-11-16 16:48:05'),(4,'od- 004','e21cs022',NULL,'jerry',NULL,'cse',NULL,'od','fever','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'approved','approved','approved','pending','2024-11-16 16:59:10','2024-11-16 17:03:14'),(5,'od- 5','e21cs089',NULL,NULL,'Tom','cse',NULL,'od','paper submittg conference','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'approved','approved','rejected','pending','2024-11-16 17:01:10','2024-11-16 17:05:24'),(6,'od-006','e21cs001','madhu',NULL,NULL,'ece',4,'od','tour pooorom','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'pending','pending','pending','pending','2024-11-17 06:15:40','2024-11-17 06:15:40'),(7,'casual_leave-001','e21cs005','karthi',NULL,NULL,'ece',4,'casual_leave','fever','2024-10-25 00:00:00','2024-10-29 00:00:00',NULL,'pending','pending','pending','pending','2024-11-17 06:16:35','2024-11-17 06:16:35');
/*!40000 ALTER TABLE `leaverequests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 15:59:12

-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: usr
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbo.devicelogs_8_2024`
--

DROP TABLE IF EXISTS `dbo.devicelogs_8_2024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbo.devicelogs_8_2024` (
  `devicelog_id` mediumint NOT NULL,
  `download_date` varchar(22) DEFAULT NULL,
  `device_id` tinyint DEFAULT NULL,
  `UserId` mediumint NOT NULL,
  `LogDate` varchar(56) DEFAULT NULL,
  `Direction` varchar(255) DEFAULT NULL,
  `AttDirection` varchar(255) DEFAULT NULL,
  `C1` varchar(4) DEFAULT NULL,
  `C2` varchar(3) DEFAULT NULL,
  `C3` varchar(4) DEFAULT NULL,
  `C4` varchar(4) DEFAULT NULL,
  `C5` varchar(4) DEFAULT NULL,
  `C6` varchar(4) DEFAULT NULL,
  `C7` varchar(255) DEFAULT NULL,
  `WorkCode` varchar(2) DEFAULT NULL,
  `UpdateFlag` tinyint DEFAULT NULL,
  `EmployeeImage` tinyint DEFAULT NULL,
  `FileName` varchar(3) DEFAULT NULL,
  `Longitude` varchar(4) DEFAULT NULL,
  `IsApproved` varchar(7) DEFAULT NULL,
  `CreatedDate` varchar(232) DEFAULT NULL,
  `LastModifiedDate` varchar(34) DEFAULT NULL,
  `BodyTemperature` decimal(2,1) NOT NULL,
  `IsMaskOn` varchar(2) DEFAULT NULL,
  `HrappSync` varchar(3) DEFAULT NULL,
  `FailureReason` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`devicelog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.devicelogs_8_2024`
--

LOCK TABLES `dbo.devicelogs_8_2024` WRITE;
/*!40000 ALTER TABLE `dbo.devicelogs_8_2024` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.devicelogs_8_2024` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 15:59:13

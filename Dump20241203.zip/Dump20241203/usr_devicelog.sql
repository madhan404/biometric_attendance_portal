-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: usr
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `devicelog`
--

DROP TABLE IF EXISTS `devicelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devicelog` (
  `devicelog_id` mediumint NOT NULL,
  `download_date` varchar(19) DEFAULT NULL,
  `device_id` tinyint DEFAULT NULL,
  `sin_number` varchar(33) NOT NULL,
  `log_date` varchar(19) DEFAULT NULL,
  `log_status` enum('in','out') DEFAULT NULL,
  PRIMARY KEY (`devicelog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devicelog`
--

LOCK TABLES `devicelog` WRITE;
/*!40000 ALTER TABLE `devicelog` DISABLE KEYS */;
INSERT INTO `devicelog` VALUES (3519,'2024-09-09 17:28:20',23,'e21cs022','2024-09-09 09:28:16','in'),(3520,'2024-09-09 17:30:45',23,'e21cs037','2024-09-09 08:30:40','in'),(3521,'2024-09-09 17:35:10',24,'e21cs014','2024-09-09 09:35:05','in'),(3522,'2024-09-09 17:40:30',23,'e21cs020','2024-09-09 11:40:25','in'),(3523,'2024-09-09 17:45:50',25,'e21cs001','2024-09-09 05:45:45','in');
/*!40000 ALTER TABLE `devicelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 15:59:12
